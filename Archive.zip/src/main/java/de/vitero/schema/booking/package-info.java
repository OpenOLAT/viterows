@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.vitero.de/schema/booking", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package de.vitero.schema.booking;
