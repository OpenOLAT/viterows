@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.vitero.de/schema/user", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package de.vitero.schema.user;
