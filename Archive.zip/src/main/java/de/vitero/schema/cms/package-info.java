@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.vitero.de/schema/cms", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package de.vitero.schema.cms;
